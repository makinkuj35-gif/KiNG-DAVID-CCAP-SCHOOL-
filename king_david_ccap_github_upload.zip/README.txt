KING DAVID CCAP SCHOOL WEBSITE

Files:
- index.html: Home page
- about.html: About and contact page
- services.html: School fees page
- intro.html: Redirects visitors to the home page
- css/style.css: Website styling

PREVIEW:
Open index.html in a web browser. Keep the css folder in the same directory.

PUBLISH ON GITHUB PAGES:
1. Sign in to GitHub and create a new repository.
2. Upload all four HTML files and the css folder, keeping the same folder structure.
3. Open the repository's Settings, then Pages.
4. Under Build and deployment, select Deploy from a branch.
5. Select the main branch and the root folder, then save.
6. Wait for GitHub Pages to publish the website. GitHub will show the website address in the Pages section.

IMPORTANT:
This is a static website suitable for GitHub Pages. The contact buttons open WhatsApp or the phone dialler. No database or working email subscription/contact form is included. GitHub Pages cannot directly run PHP or connect securely to a MySQL database. A separate backend/API is needed if you later want online forms, learner records, payments or a MySQL database.

CONTENT TO CHECK:
The supplied HTML listed the location as near Chawama, Old Spur, Lusaka; this wording has been retained. The supplied fee amounts (K500, K520, K570 and K600) have also been retained and should be confirmed by the school before publishing.
